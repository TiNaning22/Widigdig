<?php
// File: admin/controllers/auth-handler.php
require_once 'AuthController.php';

$controller = new AuthController();
$controller->handleAction();
