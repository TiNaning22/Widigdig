<div class="partner-header fade-up">
    <h2 class="partner-title">Partner Kami</h2>
</div>
<section class="partner">
    <div class="partner-container">
        <div class="partner-cards-wrapper fade-up">
            <div class="partner-card">
                <img src="../../../assets/images/EViews_logo.svg.png" alt="Partner 1">
            </div>
            <div class="partner-card">
                <img src="../../../assets/images/LogoNVIVO.png" alt="Partner 2">
            </div>
            <div class="partner-card">
                <img src="../../../assets/images/SmartPLS_Logo.png" alt="Partner 3">
            </div>
            <div class="partner-card">
                <img src="../../../assets/images/png-transparent-spss-hd-logo-removebg-preview.png" alt="Partner 4">
            </div>
            <div class="partner-card">
                <img src="../../../assets/images/logo-blue.png" alt="Partner 5">
            </div>
        </div>
    </div>
</section>
